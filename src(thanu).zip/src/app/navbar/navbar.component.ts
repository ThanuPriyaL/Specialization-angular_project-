import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
val:string="";
va:string="";
value:string="";
flag:boolean=false;
  constructor() { }

  ngOnInit(): void {
  }
  car(v:any,v2:any){
    this.val=`${Math.round(v*v2*0.07)}`;
  }
  home(b:any,b2:any){
    this.va=`${Math.round(b*b2*0.05)}`;
  }
  Personal(c:any,c2:any){
    this.value=`${Math.round(c*c2*0.04)}`;
  }
    change(){
      if(this.flag){
        this.flag=!this.flag; }
      else{
          this.flag=!this.flag;
        }
  }
}
